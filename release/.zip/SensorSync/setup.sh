cd /home/pi/Desktop/SensorSync
chmod -R u+rwx,g+rwx ./

#Install the jq command to be able to execute the readLocalDB.sh script
sudo apt install jq