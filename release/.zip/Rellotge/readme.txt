Configuration of Tactile Screen:
--------------------------------

# Modify file config.txt on the SD card root folder.

max_usb_current=1
hdmi_group=2
hdmi_mode=1
hdmi_mode=87
hdm_cvt 1024 600 60 6 0 0 0
hdmi_drive=1