#!/bin/sh
cd /home/pi/Desktop/rellotge
sudo java -jar scanner.jar