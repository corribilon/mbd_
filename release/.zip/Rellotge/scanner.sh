#!/bin/sh
cd /home/pi/Desktop/Rellotge
sudo java -jar scanner.jar