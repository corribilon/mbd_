echo "Waiting Finger"
sleep 3
echo "Put Finger again"
sleep 3
echo "Characterics: [3, 6, 5, 5, 67, 5]"
echo "Hash: aaassssssaaaaaassss333335555333"
echo "End Enrollment"
