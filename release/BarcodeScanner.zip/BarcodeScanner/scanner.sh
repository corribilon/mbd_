#!/bin/sh
cd /home/pi/Desktop/BarcodeScanner
java -jar scanner.jar