#!/bin/sh
cd /home/pi/Desktop/SensorSync
sudo java -jar photodownload.jar