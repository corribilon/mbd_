cd /home/pi/Desktop/SensorSync
chmod -R u+rwx,g+rwx ./