clear
cd /home/pi/Desktop/Enrollment
java -jar enrollment.jar 