#!/bin/sh
cd /home/pi/Desktop/rellotgeNEW
sudo java -jar scanner.jar